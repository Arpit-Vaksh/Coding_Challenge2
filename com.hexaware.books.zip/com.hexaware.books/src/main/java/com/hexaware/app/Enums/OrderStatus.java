package com.hexaware.app.Enums;

public enum OrderStatus {
    PENDING,
    COMPLETED,
    CANCELED
}
