package com.hexaware.app.Enums;

public enum UserRole {
	 
		ADMIN,
		USER
}
