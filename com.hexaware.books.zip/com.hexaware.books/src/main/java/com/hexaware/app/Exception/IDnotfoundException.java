package com.hexaware.app.Exception;

public class IDnotfoundException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IDnotfoundException(String message) {
        super(message);
    }
}
